/**
 * Provides various utility classes for creating neural networks,
 * type codes, parsing vectors, etc.
 */

package org.neuroph.util;