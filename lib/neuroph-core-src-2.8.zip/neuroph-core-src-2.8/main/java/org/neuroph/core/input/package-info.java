/**
 * Provides common neuron input functions
 */

package org.neuroph.core.input;

