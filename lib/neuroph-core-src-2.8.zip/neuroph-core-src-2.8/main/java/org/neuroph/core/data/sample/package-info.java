/**
 * Provides data sampling techniques
 */
package org.neuroph.core.data.sample;
